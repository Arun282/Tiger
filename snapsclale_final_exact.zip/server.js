
const express=require("express");
const session=require("express-session");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const path=require("path");
const crypto=require("crypto");

const app=express();
const db=new Database(path.join(__dirname,"data.db"));
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS purchases(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 product TEXT NOT NULL,
 amount INTEGER NOT NULL,
 currency TEXT NOT NULL DEFAULT 'INR',
 status TEXT NOT NULL,
 gateway_id TEXT,
 created_at TEXT NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS bank_accounts(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 holder TEXT NOT NULL,
 bank TEXT NOT NULL,
 account_enc TEXT NOT NULL,
 ifsc TEXT NOT NULL,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
`);

const ADMIN_USER=process.env.ADMIN_USERNAME||"aroh097";
const ADMIN_PASS=process.env.ADMIN_PASSWORD||"Arun@123";
const SESSION_SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex");
const ENC_KEY=crypto.createHash("sha256").update(process.env.BANK_ENCRYPTION_KEY||SESSION_SECRET).digest();

function enc(value){
 const iv=crypto.randomBytes(12),c=crypto.createCipheriv("aes-256-gcm",ENC_KEY,iv);
 const out=Buffer.concat([c.update(value,"utf8"),c.final()]);
 return [iv.toString("base64"),c.getAuthTag().toString("base64"),out.toString("base64")].join(".");
}
function dec(value){
 const [iv,tag,data]=value.split("."); const d=crypto.createDecipheriv("aes-256-gcm",ENC_KEY,Buffer.from(iv,"base64"));
 d.setAuthTag(Buffer.from(tag,"base64"));
 return Buffer.concat([d.update(Buffer.from(data,"base64")),d.final()]).toString("utf8");
}

const exists=db.prepare("SELECT id FROM users WHERE username=?").get(ADMIN_USER);
if(!exists){
 const hash=bcrypt.hashSync(ADMIN_PASS,12);
 db.prepare("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)")
 .run(ADMIN_USER,hash,"admin",new Date().toISOString());
 console.log("Created admin:",ADMIN_USER);
}

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:false}));
app.use(session({
 secret:SESSION_SECRET,
 resave:false,
 saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:1000*60*60*8}
}));
app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next){if(!req.session.user)return res.status(401).json({error:"Login required"});next()}
function admin(req,res,next){if(req.session.user?.role!=="admin")return res.status(403).json({error:"Admin only"});next()}

app.post("/api/auth/register",async(req,res)=>{
 const {username,password}=req.body||{};
 if(!username||!password||password.length<8)return res.status(400).json({error:"Username and password (8+ chars) required"});
 try{
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)").run(username,hash,"user",new Date().toISOString());
  req.session.user={id:info.lastInsertRowid,username,role:"user"};
  res.json({ok:true,user:req.session.user});
 }catch(e){res.status(409).json({error:"Username already exists"});}
});
app.post("/api/auth/login",async(req,res)=>{
 const {username,password}=req.body||{};
 const u=db.prepare("SELECT * FROM users WHERE username=?").get(username||"");
 if(!u||!(await bcrypt.compare(password||"",u.password_hash)))return res.status(401).json({error:"Invalid credentials"});
 req.session.user={id:u.id,username:u.username,role:u.role};
 res.json({ok:true,user:req.session.user});
});
app.post("/api/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/auth/me",(req,res)=>res.json({user:req.session.user||null}));

app.get("/api/admin/purchases",admin,(req,res)=>{
 const rows=db.prepare(`SELECT p.id,u.username,p.product,p.amount,p.currency,p.status,p.gateway_id,p.created_at
 FROM purchases p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC`).all();
 res.json({purchases:rows});
});
app.post("/api/purchases",auth,(req,res)=>{
 const {product,amount,currency="INR",status="pending",gateway_id=null}=req.body||{};
 if(!product||!Number.isInteger(Number(amount)))return res.status(400).json({error:"Invalid purchase"});
 const info=db.prepare(`INSERT INTO purchases(user_id,product,amount,currency,status,gateway_id,created_at)
 VALUES(?,?,?,?,?,?,?)`).run(req.session.user.id,product,Number(amount),currency,status,gateway_id,new Date().toISOString());
 res.json({ok:true,id:info.lastInsertRowid});
});
app.get("/api/admin/bank",admin,(req,res)=>{
 const b=db.prepare("SELECT * FROM bank_accounts ORDER BY id DESC LIMIT 1").get();
 if(!b)return res.json({bank:null});
 let account=""; try{account=dec(b.account_enc)}catch{}
 res.json({bank:b?{id:b.id,holder:b.holder,bank:b.bank,account,ifsc:b.ifsc}:null});
});
app.post("/api/admin/bank",admin,(req,res)=>{
 const {holder,bank,account,ifsc}=req.body||{};
 if(!holder||!bank||!account||!ifsc)return res.status(400).json({error:"All bank fields are required"});
 const now=new Date().toISOString(), old=db.prepare("SELECT id FROM bank_accounts ORDER BY id DESC LIMIT 1").get();
 if(old)db.prepare("UPDATE bank_accounts SET holder=?,bank=?,account_enc=?,ifsc=?,updated_at=? WHERE id=?").run(holder,bank,enc(account),ifsc,now,old.id);
 else db.prepare("INSERT INTO bank_accounts(holder,bank,account_enc,ifsc,created_at,updated_at) VALUES(?,?,?,?,?,?)").run(holder,bank,enc(account),ifsc,now,now);
 res.json({ok:true});
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`SnapScale server running on http://localhost:${port}`));
