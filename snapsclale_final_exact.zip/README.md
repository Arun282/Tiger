# SnapScale Production Auth Backend

This package upgrades the prototype to a real server-side authentication/data layer.

## Features
- Public registration/login
- Admin login
- Password hashing with bcrypt
- Server-side sessions
- SQLite database
- Admin purchase dashboard API
- Encrypted bank-account number at rest
- Purchase records stored server-side
- Admin credentials seeded from environment variables

## Run

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## Admin
Default development credentials:
- Username: `aroh097`
- Password: `Arun@123`

For production, set `ADMIN_USERNAME` and `ADMIN_PASSWORD` as hosting secrets and change the password.

## Payment gateway
The purchase API records a purchase but does **not** charge money. A real payment gateway must be connected (for example Razorpay/Stripe) and its secret keys must remain server-side. The gateway webhook should update `purchases.status` and `gateway_id`.

Never put bank credentials, gateway secrets, or admin passwords in frontend JavaScript.


## UI fidelity
The frontend is rebuilt specifically around the supplied 1536×1024 reference:
- same 3-column editor composition
- glass/dark panels
- purple active states
- top search and Download/Export controls
- left navigation labels
- right Adjust/Filters/Effects/Background/AI Tools tabs
- bottom tool strip
- responsive behavior for smaller screens

The editor remains functional; the UI is not a screenshot image.


## Final visual/functionality pass
Desktop layout is locked to the supplied reference proportions: 220px left rail, 488px right panel, 28px gaps, 27px outer margins. All visible left/bottom/right tools have their own panel and action instead of generic placeholders.
